var i = 0;
var txt = "Hey you! For some reason, I always thinking 'bout you. I like every part of you, even your feet. Well I love spending time with you and honestly I think you're incredible. You have a heart full of love for the world that I strive to match. You also laugh at my dumb jokes and have a great sense of humor yourself, and I love so much that we click in that way. I also think you have super dope taste in music and also shows and movies and I love that we can enjoy all of those together. You're also drop dead gorgeous. Every day we spend together feels like the only day that will ever matter, and I never want it to end. I get to be the person who you deem worth being with and it means the world to me 💜"; /* The text */
var speed = 50; /* The speed/duration of the effect in milliseconds */

function typeWriter() {
  if (i < txt.length) {
    document.getElementById("paragraf").innerHTML += txt.charAt(i);
    i++;
    setTimeout(typeWriter, speed);
  }
}